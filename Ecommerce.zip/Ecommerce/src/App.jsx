import { useState } from 'react'
import './output.css'
import './assets/style.css'
import Header from './Components/Header'
import ProductPage from './Components/ProductPage'

function App() {

  return (
    <>
      <Header/>
        <ProductPage/>
    </>
  )
}

export default App
