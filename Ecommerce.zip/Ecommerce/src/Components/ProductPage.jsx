import React, { useEffect, useState } from 'react'
import ItemCard from './ItemCard'
import { FaAnglesLeft, FaAnglesRight } from "react-icons/fa6";

const ProductPage = () => {
    const [loading, setloading] = useState(true);
    const [data, setdata] = useState([]);
    const [currentPage, setcurrentpage] = useState(1)

    useEffect(() => {

        const loaddata = async () => {
            const response = await fetch('https://fakestoreapi.com/products');
            setdata(await response.json());
            setloading(false)
        }
        loaddata();
    }, [])


    if (loading) {
        return (
            <div className='text-lg font-bold'>Loading</div>
        )
    }
    if (!loading) {
        return (   
            <> 
            <div className='px-6 py-5'>
                <h1 className='text-black text-lg font-bold'>New launches</h1>
                <div className='container mx-auto px-8'>
                    <div className='bg-white p-1 my-5 flex flex-wrap justify-around px-8'>
                  {
                    data.map((item)=>{
                        return <ItemCard 
                        key={item.id}
                        name = {item.title} 
                        price = {item.price}
                        image_src = {item.image}
                        star_rating={item.rating.rate}
                        description = {item.description}
                         />
                    }
                    )
                    }
                </div>
                </div>
            </div>
           </>
        )
    }
}

export default ProductPage
