import React from 'react'

const Header = () => {
    const currentdate = new Date();

    const formatedate = currentdate.toLocaleDateString();
    const formateTime = currentdate.toLocaleTimeString();
  return (
    <>
        <div className='flex justify-between px-6 py-4 bg-blue-950 text-white items-center'>
            <div>
            <p className='font-semibold'>{formatedate},  {formateTime}</p>
            <p className='text-lg'>PS Intelegencia</p>
            </div>
            <div>
                <input type="text" className='p-1 outline-none rounded-sm text-black text-sm' placeholder='Search here...' />
            </div>
        </div>
    </>
  )
}

export default Header