import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { MdCurrencyRupee } from "react-icons/md";
import { FaStar } from "react-icons/fa";

const ItemCard = ({name, price, image_src, star_rating, description}) => {
  return (
    <>
      <div className='itemcard p-2 w-1/4 mb-2 bg-gray-300'>
       <div className='h-40 w-50 bg-white p-2'>
       <img className='w-full h-full object-contain hover:scale-125' src={image_src} alt="" /></div>
        <div className='flex justify-between mt-2 '>
          <span className='font-semibold'>{name.substring(0,16)}... </span>
          <span className='flex items-center'><MdCurrencyRupee /> {price}</span>
        </div>
        <p className='text-sm truncate'>{description}
        </p>
        <div className='flex justify-between items-center mt-2'>
          <p className='flex justify-around items-center'><FaStar /> {star_rating} </p>
          <button className='bg-green-500 text-white text-sm rounded-sm p-1 px-2'>Add to Cart</button>
        </div>
      </div>
    </>
      
  )
}

export default ItemCard